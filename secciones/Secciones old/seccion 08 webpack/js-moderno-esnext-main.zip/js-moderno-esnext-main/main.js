import './style.css';
// import './01-arrays/array-with';
import './01-arrays/array-to-methods';

document.querySelector('#app').innerHTML = `
  <h1>Hola!</h1>
`
