import { heroesCiclo, heroeIfAwait } from './js/await';

heroesCiclo();


heroeIfAwait('iron');









