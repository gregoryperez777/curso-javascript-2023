# js-moderno-advanced

Recuerden realizar el ```npm install```, para reconstruir los módulos de node

Luego ```npm run dev``` para ejecutar la aplicación
