export const heroes = [{
    "id": "5d86371f1efebc31def272e2",
    "about": "Ipsum duis incididunt ullamco tempor. Amet incididunt Lorem consequat labore culpa. Pariatur amet veniam reprehenderit sunt laborum excepteur. Labore eu ut ut Lorem labore aliqua quis ex elit nulla in incididunt commodo aliquip. Velit excepteur eiusmod Lorem esse officia. Irure aliquip Lorem fugiat voluptate dolor duis consectetur aliquip pariatur tempor reprehenderit deserunt.",
    "picture": "https://www.sideshow.com/storage/product-images/903421/iron-man_marvel_gallery_5c4cced10da7f.jpg",
"squarePic": "https://dam.smashmexico.com.mx/wp-content/uploads/2018/06/27181227/ironman_portada2.jpg",
    "name": "Iron Man"
},
{
    "id": "5d86371f2343e37870b91ef1",
    "about": "Mollit officia ad excepteur anim proident incididunt eiusmod mollit consectetur id sit velit. Laborum ut magna officia qui laboris eiusmod do culpa. Culpa dolor officia velit cillum culpa deserunt cupidatat cillum ipsum laborum.",
    "picture": "https://vignette.wikia.nocookie.net/marvelvscapcom/images/5/5d/HulkBruce.png/revision/latest?cb=20170818123736",
"squarePic": "https://bolavip.com/__export/1557252167649/sites/bolavip/img/2019/05/07/hulk_crop1557252167265.jpg_1693159006.jpg",
    "name": "Hulk"
},
{
    "id": "5d86371f25a058e5b1c8a65e",
    "about": "Laboris est duis eiusmod adipisicing cillum ut sit ea Lorem non laboris quis Lorem. Est culpa esse aliqua non labore dolor esse labore nulla mollit. Nostrud amet est quis adipisicing dolor. Labore veniam elit veniam non ad ex consequat excepteur eiusmod. Minim cupidatat velit Lorem culpa quis consequat incididunt qui amet incididunt pariatur ex aliquip aliqua. Magna ex elit in aliquip minim eu ut ut fugiat ullamco deserunt adipisicing cillum.",
    "picture": "https://i.pinimg.com/736x/ba/9b/36/ba9b3623c9a639296e85f7ff09c3c205.jpg",
    "name": "Captain America"
},
{
    "id": "5d86371f9f80b591f499df32",
    "about": "Ipsum tempor sunt Lorem est. Fugiat nisi velit veniam labore et ullamco minim adipisicing do culpa. Cillum voluptate reprehenderit aute consectetur.",
    "picture": "http://im.rediff.com/movies/2019/mar/06captain-marvel1.jpg",
"squarePic": "https://img.chilango.com/2018/05/quien-es-capitan-marvel.jpg",
    "name": "Captain Marvel"
},
{
    "id": "5d86371f233c9f2425f16916",
    "about": "Deserunt voluptate aliquip ex dolor Lorem exercitation aliqua nisi fugiat aliquip sunt non. Eu cillum enim velit exercitation officia proident exercitation ipsum exercitation Lorem nulla do. Minim sint dolor nostrud ipsum laborum. Velit ea ad ad consectetur nisi Lorem laborum officia esse. Do eu incididunt eiusmod voluptate excepteur consequat ipsum ad. Quis veniam exercitation eiusmod amet non non eu aliquip quis ea. Tempor deserunt nulla adipisicing qui fugiat ipsum labore duis et ea consectetur.",
    "picture": "https://m.media-amazon.com/images/M/MV5BYTU4NmRhNTctMjI2ZS00ZTUyLWI1ZjEtZWU1ODAxMjM5MzlmXkEyXkFqcGdeQXVyNDQxNjcxNQ@@._V1_UY1200_CR165,0,630,1200_AL_.jpg",
"squarePic": "https://wipy.tv/wp-content/uploads/2019/07/filtran-el-tr%C3%A1iler-de-%E2%80%98Black-Widow%E2%80%99.jpg",
    "name": "Black Widow"
},
{
    "id": "5d86371f97c29d020f1e1f6d",
    "about": "Esse magna Lorem ipsum incididunt sit. Enim eiusmod proident in adipisicing anim excepteur laborum magna aliqua adipisicing ad qui aliqua. Eiusmod enim ullamco laboris adipisicing tempor sint labore. Exercitation cupidatat incididunt nostrud velit nisi aute eu ex pariatur deserunt mollit. Deserunt nisi enim irure elit. Aute amet amet consequat laborum dolor sint anim Lorem id fugiat commodo cupidatat ad. Ipsum quis enim consectetur occaecat laboris esse.",
    "picture": "https://vignette.wikia.nocookie.net/marvelcinematicuniverse/images/4/48/Falcon_AIW_Profile.jpg/revision/latest/scale-to-width-down/310?cb=20180518212822",
"squarePic": "https://www.tooys.mx/pub/media/catalog/product/cache/89d4a95274a31fe8bdfcc437494b2c9e/f/a/falcon_marvel_gallery_5c4dc5df6c14d_-_copia.jpg",
    "name": "Falcon"
},
{
    "id": "5d86371fd55e2e2a30fe1ccb",
    "about": "Id aute in dolore dolor in incididunt dolore duis do mollit officia. Ullamco pariatur eiusmod laborum culpa quis non occaecat ad cillum dolore labore aliqua. Elit magna commodo aliquip laborum aliqua duis.",
    "picture": "https://vignette.wikia.nocookie.net/marvelcinematicuniverse/images/9/99/Black_Panther_AIW_Profile.jpg/revision/latest/scale-to-width-down/310?cb=20180518212436",
"squarePic": "http://www.mundocinematografico.net/wp-content/uploads/2018/02/black-panther-marvel-cosas-felices.jpg",
    "name": "Black Panther"
},
{
    "id": "5d86371fd55e2e2a30fe1ccb1",
    "about": "Id aute in dolore dolor in incididunt dolore duis do mollit officia. Ullamco pariatur eiusmod laborum culpa quis non occaecat ad cillum dolore labore aliqua. Elit magna commodo aliquip laborum aliqua duis.",
    "picture": "https://www.outland.no/media/catalog/product/cache/6f3b753be090e58846a92333dfe1de97/4/8/4897011186276_4.jpg",
"squarePic": "https://img-cdn.hipertextual.com/files/2019/09/hipertextual-filtracion-revela-que-doctor-strange-2-resucitara-dos-personajes-muertos-marvel-2019435911.jpg?strip=all&lossy=1&quality=57&resize=740%2C490&ssl=1",
    "name": "Doctor Strange"
}, {
    "id": "5d86371fd55e2e2a30fe1ccb2",
    "about": "Id aute in dolore dolor in incididunt dolore duis do mollit officia. Ullamco pariatur eiusmod laborum culpa quis non occaecat ad cillum dolore labore aliqua. Elit magna commodo aliquip laborum aliqua duis.",
    "picture": "https://www.sideshow.com/storage/product-images/903735/spider-man-advanced-suit_marvel_silo.png",
"squarePic": "https://e00-marca.uecdn.es/assets/multimedia/imagenes/2019/09/28/15696592030335.jpg",
    "name": "Spider Man"
},
{
    "id": "5d86371fd55e2e2a30fe1cc3",
    "about": "Id aute in dolore dolor in incididunt dolore duis do mollit officia. Ullamco pariatur eiusmod laborum culpa quis non occaecat ad cillum dolore labore aliqua. Elit magna commodo aliquip laborum aliqua duis.",
    "picture": "https://fsmedia.imgix.net/f5/ba/d8/66/7dd4/44e9/8e0a/d91348489582/ant-man-and-the-wasp-2018.jpeg#image",
"squarePic": "https://img.chilango.com/2018/05/quien-es-capitan-marvel.jpg",
    "name": "Ant Man"
},
{
    "id": "5d86371fd55e2e2a30fe1cc4",
    "about": "Id aute in dolore dolor in incididunt dolore duis do mollit officia. Ullamco pariatur eiusmod laborum culpa quis non occaecat ad cillum dolore labore aliqua. Elit magna commodo aliquip laborum aliqua duis.",
    "picture": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6Qum9HPm82yeUaFuMhpo3A98HbgsyUSDmk1cUNS4C2rb31BHZ2w",
"squarePic": "https://img.chilango.com/2018/05/quien-es-capitan-marvel.jpg",
    "name": "The Wasp"
}
];