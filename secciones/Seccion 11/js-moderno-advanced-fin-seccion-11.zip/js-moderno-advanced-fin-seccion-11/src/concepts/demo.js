
/**
 * 
 * @param {HTMLDivElement} element 
 */
 export const demoComponent = ( element ) => {

    console.log('demoComponent');


}

