# js-moderno-vite-todo

1. Clonar repositorio
2. Ejecutar ```npm install```
3. Ejecutar ```npm run dev``` para correr en desarrollo
